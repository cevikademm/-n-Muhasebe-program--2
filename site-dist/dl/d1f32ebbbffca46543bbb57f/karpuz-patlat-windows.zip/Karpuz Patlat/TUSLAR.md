# Karpuz Patlat — tuşlar

Oyunda **F2** aynı listeyi gösterir; **F3 Test paneli** her işlevi tek tek dener. Bu dosya `Tools → Karpuz Patlat → 8` ile de üretilir.
Tuş değiştirmek: `KarpuzPatlat_Data/StreamingAssets/KarpuzPatlat/keybindings.json` (Unity KeyCode adı). Çakışma testi: NUnit `KeyBindingTests`.
Numpad: izleyici tuşları 1–0 sayı tuşları ile **Num 1–Num 0** aynı işi yapar.


## OYUN AKIŞI

| Tuş | İşlev | Açıklama |
|---|---|---|
| Enter | Oyunu başlat | Ana menüde seçili düğmeyi onaylar. Menü açılınca 'Oyunu Başlat' seçili gelir. |
| P | Duraklat / devam et | Oyunu dondurur; yayında 'DURAKLATILDI' yazısı görünür. Tekrar P ile devam eder. |
| Esc | Menü / geri | Oyun sırasında duraklatma menüsünü açar. Menülerde bir önceki ekrana döner. |
| R  (2 kez) | Yeniden başlat | Kazara basılmasın diye 2,5 sn içinde iki kez basılır. Oyun Tur 1'den başlar. |
| Home | Ana menüye dön | Oyunu durdurur ve ana menüyü açar. |
| Q | Oyundan çık | Onay penceresi açar: Enter = çık, Esc = vazgeç. |

## EKRANLAR

| Tuş | İşlev | Açıklama |
|---|---|---|
| F1 | Ayarlar | Bağlantı, meyve modu, katılım, güvenlik, ses. 'Kaydet' ile config.json'a yazılır. |
| F2 | Kontroller | Bu listeyi gösterir. |
| F3 | Test paneli | Her özelliği tek tek dener, çalışıp çalışmadığını yazar. |
| F4 | Nasıl oynanır? | Oyunun amacı, izleyici komutları ve hediyeler. |
| F6 | Teşhis (TikFinity / webhook) | Ayarlar'ı Webhook sekmesinde açar: bağlantı durumu, sayaçlar, son olaylar ve webhook adresleri. |

## İZLEYİCİ SİMÜLASYONU (TikTok olaylarının aynısı)

| Tuş | İşlev | Açıklama |
|---|---|---|
| 1 | Lastik tak | Bir izleyici normal lastik takar (Gül hediyesi gibi). Karpuz biraz sıkışır. |
| 2 | Kalın lastik | 3 kat sıkar (Finger Heart). |
| 3 | Altın lastik | 5 kat sıkar, ışıltı + bildirim (TikTok hediyesi). Altınla patlatan 2 puan alır. |
| 4 | Lastik yağmuru | 8 lastik art arda takılır (Doughnut). |
| 5 | Makas | En üstteki 2 lastiği keser (Perfume). Karpuzda lastik yoksa etkisizdir. |
| 6 | Koli bandı | Karpuzu rahatlatır, patlamayı geciktirir (Hand Hearts). |
| 7 | Lastik çıkar | Lastikçi son takılan 3 lastiği çeker (Corgi). Lastik yoksa etkisizdir. |
| 8 | Dev çekiç | Karpuzu anında patlatır (5 Rosa kombosu). |
| 9 | Takip etti | Yeni takipçi: 'Hoş geldin' bildirimi + 1 lastik. |
| 0 | Abone oldu | Abone: ayarlardaki abone ödülü (varsayılan kalın lastik). |
| L | Beğeni paketi | Beğeni eşiği doldu: 1 lastik. Ayarlarda 'Beğeni ile katılım' açık olmalı. |

## TEST ARAÇLARI

| Tuş | İşlev | Açıklama |
|---|---|---|
| A | Otomatik oynat | Yayın yokken oyunu sahte izleyicilerle kendi kendine oynatır (aç/kapa). |
| Boşluk | 5 sn yük testi | 5 saniye boyunca saniyede 4 rastgele olay gönderir. |
| Y | Sürekli yük | Saniyede 4 olay, kapatılana kadar (aç/kapa). |

## YAYINCI / OPERATÖR

| Tuş | İşlev | Açıklama |
|---|---|---|
| B | Şimdi patlat | Karpuzu hemen patlatır; kazanan son lastiği takan olur. Sadece tur sürerken. |
| N | Turu atla | Kazanan çıkarmadan sonraki tura geçer. Sadece tur sürerken. |
| M | Sesi kapat / aç | Tüm sesleri susturur. |
| T | Liderlik tablosu | Sol alttaki liderler kutusunu gösterir/gizler. |
| G | Güvenli mod | Pembe meyve suyu, ad filtresi, az sarsıntı (aç/kapa). Meyve rengi yeni turda değişir. |
| F5 | TikFinity'ye yeniden bağlan | Bağlantıyı kapatıp yeniden kurar. Durum sağ üstteki noktada (yeşil = bağlı). |
| F12 | Ekran görüntüsü | Oyun klasöründeki 'EkranGoruntuleri' içine PNG kaydeder. |

## Ayarlar paneli (F1 / F6)

| Tuş | İşlev |
|---|---|
| Tab / Shift+Tab | Sonraki / önceki sekme (Oyun · Hediye eşleme · Webhook · Sohbet · Lisans) |
| Esc | Paneli kapat |

## Lisans kilit ekranı

| Tuş | İşlev |
|---|---|
| R / F5 | Yeniden sorgula |
| C | Cihaz kodunu kopyala |
| Esc | Oyundan çık |

## Yayıncı komutu (TikTok sohbeti)

| Komut | İşlev |
|---|---|
| !onay | Lisans bir TikTok hesabına bağlıysa, yayıncı kendi hesabından yazınca canlı olaylar işlenmeye başlar |
| katıl / katil / join / 🍉 / lastik | İzleyici adına 1 lastik (Ayarlar → Sohbet'ten düzenlenir) |
